import java.io.*;
import java.awt.image.BufferedImage;
import java.nio.file.*;
import java.util.*;
import javax.imageio.ImageIO;

import bsh.EvalError;
import bsh.Interpreter;

public class PixelPog {

    public static void main(String[] args) throws IOException, EvalError {
        File directory = new File("C:\\Users\\psliw\\Desktop\\Space Cadets\\PixelPog\\Colour Directory.txt");
        BufferedReader reader = new BufferedReader(new FileReader(directory));
        File input = new File("C:\\Users\\psliw\\Desktop\\Space Cadets\\PixelPog\\helloworld.png");
        BufferedImage inputImage = ImageIO.read(input);
        Scanner textReader = new Scanner(System.in);
        int x,y;
        int  yLimit = inputImage.getHeight();
        int xLimit = inputImage.getWidth();
        Boolean found = false;
        String codeBuffer ="";
        Interpreter hexInterpreter = new Interpreter();

            for (y = 0; y < yLimit; y++) {
                for (x = 0; x < xLimit; x++) {
                    reader.mark(1000);
                    int numRGB = Tools.realRGB(inputImage.getRGB(x, y));
                    String RGB = Integer.toString(numRGB);
                    String dLine = "";
                    while (!found){
                        dLine = reader.readLine();
                        if (dLine == null){
                            Tools.interpret(hexInterpreter, codeBuffer);
                            Tools.stop();
                        } else if (dLine.contains(" "+RGB+"_")){
                            found = true;
                            codeBuffer = codeBuffer + dLine.substring(dLine.indexOf("_")+1, dLine.indexOf("#"));
                        }
                    }
                    found = false;
                    reader.reset();
                }
            }
        hexInterpreter.eval(codeBuffer);
    }

}

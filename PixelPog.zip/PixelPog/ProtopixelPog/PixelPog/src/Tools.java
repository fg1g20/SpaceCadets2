import bsh.EvalError;
import bsh.Interpreter;

import java.io.*;

public class Tools {
    public static int realRGB(int rgb){
        int hexMax = 16777216;
        return hexMax + rgb;
    }

    public static void intialiseJava(FileWriter w) throws IOException {
        w.write("import java.io.*;\n" +
                "import java.awt.image.BufferedImage;\n" +
                "import java.nio.file.*;\n" +
                "import java.util.*;\n" +
                "import javax.imageio.ImageIO;\n");
        w.write("public class HexCode {");
        w.write("    public static void hexCode(){");
    }
    public static void closeJava(FileWriter w, String s) throws IOException {
        w.write("   "+s);
        w.write("   }");
        w.write("}");
        w.close();
    }
    public static void stop(){
        //System.out.println("Error at compilation");
        System.exit(0);
    }
    public static void interpret(Interpreter i, String a) throws EvalError {
        i.eval(a);
    }
}
